---
name: sidekick-content-calendar
description: Generates monthly content calendars from approved strategies with dates, pillars, topics, formats, and caption outlines. Use when (1) creating first month's calendar for new client, (2) generating next month's content plan, (3) rebuilding calendar after strategy update. Requires channel strategy docs (00_IG_STRATEGY.md, 00_FB_STRATEGY.md, etc.).
---

# Sidekick Content Calendar Generator

Transform approved social media strategies into per-channel monthly content calendars with specific dates, formats, pillars, topics, caption outlines, and visual directions.

## Output Structure

```
07_Marketing_Channels/Social_Media/
├── Instagram/
│   └── Content_Calendars/
│       ├── YYYY-MM_IG_Calendar.csv
│       └── YYYY-MM_IG_Brief.md
├── Facebook/
│   └── Content_Calendars/
│       ├── YYYY-MM_FB_Calendar.csv
│       └── YYYY-MM_FB_Brief.md
├── GBP/
│   └── Content_Calendars/
│       ├── YYYY-MM_GBP_Calendar.csv
│       └── YYYY-MM_GBP_Brief.md
```

## Quick Start

Generate calendar structure with placeholder topics:

```bash
python scripts/generate_calendar.py --client-folder "{{client_folder}}" --month "2025-02" --platform instagram
python scripts/generate_calendar.py --client-folder "{{client_folder}}" --month "2025-02" --platform facebook
python scripts/generate_calendar.py --client-folder "{{client_folder}}" --month "2025-02" --platform gbp
```

This creates per-channel:
- `YYYY-MM_[PLATFORM]_Calendar.csv` - Post schedule with [TBD] placeholders
- `YYYY-MM_[PLATFORM]_Brief.md` - Overview with pillar/format distribution

Then fill in the topics, captions, and visuals using the phases below.

## Service Model Constraints

Sidekick operates a **photo-first** content strategy:
- 50-60% Carousels
- 30-35% Single Images
- 5-10% Monthly Recap Reel
- No daily Stories or video-first content

## Phase 1: Load Strategy & Context

### Step 1: Load Strategy Documents

```bash
# Load master strategy for cross-channel elements:
Read 07_Marketing_Channels/Social_Media/00_MASTER_STRATEGY.md

# Load channel-specific strategy for the platform:
Read 07_Marketing_Channels/Social_Media/Instagram/00_IG_STRATEGY.md    # For Instagram calendar
Read 07_Marketing_Channels/Social_Media/Facebook/00_FB_STRATEGY.md    # For Facebook calendar
Read 07_Marketing_Channels/Social_Media/GBP/00_GBP_STRATEGY.md        # For GBP calendar
```

Extract from master strategy:
- Content pillars with target percentages
- Brand voice guidelines
- Quarterly themes

Extract from channel strategy:
- Platform-specific posting frequency
- Format mix targets for this channel
- Best posting times
- Hashtag strategy (IG/FB) or none (GBP)
- Channel-specific KPIs

### Step 2: Calculate Monthly Requirements

From posting frequency in strategy:
```
Example calculation:
- Instagram: 5 posts/week × 4 weeks = 20 posts
- Facebook: 4 posts/week × 4 weeks = 16 posts
- GBP: 2 posts/week × 4 weeks = 8 posts
Total: 44 posts
```

### Step 3: Calculate Pillar Distribution

Apply pillar percentages to total posts:
```
Example for 44 posts:
- Student Success (30%): 13 posts
- Educational (25%): 11 posts
- Community (20%): 9 posts
- Instructor (15%): 7 posts
- Promotional (10%): 4 posts
```

### Step 4: Calculate Format Distribution

Apply photo-first targets per platform:
```
Example for 20 Instagram posts:
- Carousels (55%): 11 posts
- Single Images (35%): 7 posts
- Monthly Reel (10%): 2 posts
```

## Phase 2: Date & Theme Planning

### Step 5: Map Calendar Dates

Generate all dates in target month and identify posting days:
- Monday: High priority (IG + FB)
- Tuesday: Medium (IG + GBP)
- Wednesday: High (IG + FB)
- Thursday: Medium (IG + GBP)
- Friday: High (IG + FB)
- Saturday: Optional (light content)
- Sunday: Rest or prep

### Step 6: Identify Special Content Opportunities

Load `references/holiday_calendar.md`

Check for:
- Federal holidays
- Industry-specific dates
- Local events (from user input)
- Seasonal themes from strategy
- Client anniversaries

### Step 7: Block Avoid Dates

If `avoid_dates` provided, remove from posting schedule.

### Step 8: Assign Weekly Themes

Align with quarterly strategy theme:
```
February Example:
- Week 1: "New Year, New Skills"
- Week 2: "Valentine's Week"
- Week 3: "Mid-Winter Push"
- Week 4: "Month End Wins"
```

## Phase 3: Content Slot Assignment

### Step 9: Create Posting Schedule Grid

Assign post slots to dates by platform priority.

### Step 10: Distribute Pillars Across Calendar

Pillar placement rules:
- No pillar appears >2 consecutive days
- Promotional content spread throughout (not clustered)
- Student Success on high-engagement days (Mon, Wed)
- Educational content early in week
- Community content mid-to-end of week

### Step 11: Assign Formats to Slots

| Format | Best Days | Best Pillars |
|--------|-----------|--------------|
| Carousel | Mon, Wed, Fri | Educational, Tips, Before/After |
| Single Image | Any day | Testimonials, Quotes, Announcements |
| Monthly Reel | Last week | Recap, Highlights |

## Phase 4: Topic & Caption Development

### Step 12: Generate Topic Ideas

Load `references/topic_banks.md` for industry-specific inspiration.

For each pillar allocation, generate specific topics ensuring:
- Variety (no repeated angles)
- Seasonal relevance
- Special date alignment

### Step 13: Create Caption Outlines

**Single Image format:**
```
Hook: [attention-grabber] | Body: [2-3 sentences] | CTA: [action]
```

**Carousel format:**
```
Hook: [curiosity driver] | Slides: 1-[intro], 2-X-[points], Final-[CTA] | Body: [context] | CTA: [save/share]
```

### Step 14: Add Visual Direction

For each post, specify:
- Photo type (candid, posed, graphic, before/after)
- Subject (student, instructor, product, location)
- Mood (warm, energetic, calm, professional)
- Key elements (faces, text overlay needs)

### Step 15: Assign Hashtags

Load `references/hashtag_banks.md`

Platform-specific sets:
- Instagram: 5-10 hashtags (branded + niche + local)
- Facebook: 1-3 hashtags
- GBP: No hashtags

## Phase 5: Validation & Output

### Step 16: Balance Check

Validate distributions:
- Pillar percentages within ±5% of targets
- Format percentages within ±10% of targets
- No empty date slots
- No back-to-back promotional posts

### Step 17: Generate CSV

Load `references/calendar_template.md` for structure.

Create `YYYY-MM_[PLATFORM]_Calendar.csv` with columns:
- Date, Day, Format, Pillar, Topic
- Caption_Outline, Visual_Direction, Hashtags, Status

### Step 18: Generate Supporting Documents

**YYYY-MM_[PLATFORM]_Brief.md:**
- Total posts count
- Monthly theme
- Weekly themes
- Pillar distribution table
- Special content notes
- Format distribution breakdown

### Step 19: Save Outputs

Per-channel folder structure:
```
07_Marketing_Channels/Social_Media/Instagram/Content_Calendars/YYYY-MM_IG_Calendar.csv
07_Marketing_Channels/Social_Media/Instagram/Content_Calendars/YYYY-MM_IG_Brief.md

07_Marketing_Channels/Social_Media/Facebook/Content_Calendars/YYYY-MM_FB_Calendar.csv
07_Marketing_Channels/Social_Media/Facebook/Content_Calendars/YYYY-MM_FB_Brief.md

07_Marketing_Channels/Social_Media/GBP/Content_Calendars/YYYY-MM_GBP_Calendar.csv
07_Marketing_Channels/Social_Media/GBP/Content_Calendars/YYYY-MM_GBP_Brief.md
```

## Quality Standards

Every calendar must include:
- Complete post for every slot
- Pillar distribution within ±5%
- Caption outline for every post
- Visual direction for every post
- Platform-appropriate hashtags

Every calendar must avoid:
- Empty date slots
- Generic topics ("post about business")
- Pillar imbalances >10%
- Repeated topics in same week

## References

- `../_shared/channel_benchmarks.md` - **Research-backed engagement data, posting times, and platform specs (2024-2025)**
- `references/calendar_template.md` - CSV structure and format examples
- `references/topic_banks.md` - Industry-specific topic ideas
- `references/holiday_calendar.md` - Key dates throughout year
- `references/hashtag_banks.md` - Hashtag sets by industry/platform
