---
name: sidekick-content-writer
description: Generates platform-optimized social media captions from calendar entries with proper hooks, CTAs, and hashtags. Use when (1) writing captions for monthly calendar batch, (2) creating single post for specific topic, (3) generating A/B caption variations. Requires per-channel content calendar.
---

# Sidekick Content Writer

Transform per-channel content calendar entries into polished, ready-to-post social media captions that match the client's brand voice, follow platform best practices, and drive engagement.

## Input/Output Structure

```
07_Marketing_Channels/Social_Media/
├── Instagram/
│   └── Content_Calendars/
│       ├── YYYY-MM_IG_Calendar.csv      ← INPUT
│       └── YYYY-MM_IG_Captions.md       ← OUTPUT
├── Facebook/
│   └── Content_Calendars/
│       ├── YYYY-MM_FB_Calendar.csv      ← INPUT
│       └── YYYY-MM_FB_Captions.md       ← OUTPUT
├── GBP/
│   └── Content_Calendars/
│       ├── YYYY-MM_GBP_Calendar.csv     ← INPUT
│       └── YYYY-MM_GBP_Captions.md      ← OUTPUT
```

## Service Model Constraints

Sidekick operates a **photo-first**, caption-driven approach:
- Visuals support the message
- Consistent brand voice across all content
- Scalable, template-driven writing patterns

## Phase 1: Load Context

### Step 1: Load Calendar Entries

```bash
# From per-channel CSV files:
Read 07_Marketing_Channels/Social_Media/Instagram/Content_Calendars/YYYY-MM_IG_Calendar.csv
Read 07_Marketing_Channels/Social_Media/Facebook/Content_Calendars/YYYY-MM_FB_Calendar.csv
Read 07_Marketing_Channels/Social_Media/GBP/Content_Calendars/YYYY-MM_GBP_Calendar.csv

# Parse all columns
# Filter by date_range if specified

# For single post:
Use provided post details directly
```

### Step 2: Load Brand Voice

From strategy or voice guide, extract:
- Tone attributes (e.g., "Warm, Expert, Approachable")
- Personality description
- Language level (casual/professional)
- Do's and Don'ts
- Emoji usage guidelines

### Step 3: Load Pillar Context

For each pillar being written, review:
- Pillar description from strategy
- Target audience for this pillar
- Goal (educate, inspire, convert)

## Phase 2: Caption Generation

### Step 4: Process Each Calendar Entry

For each post, read:
- Date, Platform, Format, Pillar, Topic
- Caption_Outline, Visual_Direction, Hashtags

Apply in order:
1. Platform-specific character limits
2. Format-specific structure
3. Brand voice guidelines
4. Pillar-appropriate tone

### Step 5: Apply Platform Rules

Load `references/platform_specs.md`

| Platform | Ideal Length | Hashtags | Emoji | Tone |
|----------|--------------|----------|-------|------|
| Instagram | 125-200 (single), 300-500 (carousel) | 5-10 | Moderate | Conversational |
| Facebook | 40-80 (optimal) | 1-3 | Light | Community |
| GBP | 100-300 | None | Minimal | Professional |

### Step 6: Apply Format Rules

**Single Image:**
- Short, punchy caption
- Story-focused or value-quick
- Single clear CTA

**Carousel:**
- Longer caption acceptable
- Reference slides ("swipe through")
- Save/Share CTA emphasis

**Reel:**
- Very short (50-100 chars)
- High energy language
- Watch/Follow CTA

### Step 7: Apply Pillar Voice

Load `references/caption_templates.md` for pillar-specific patterns.

| Pillar | Tone | Key Words | CTA Style |
|--------|------|-----------|-----------|
| Student Success | Celebratory | "achieved", "journey" | "Your turn" |
| Educational | Helpful | "here's how", "mistake" | "Save this" |
| Behind-the-Scenes | Authentic | "meet", "day in life" | "Say hi" |
| Community | Warm | "grateful", "together" | "Tag a friend" |
| Promotional | Enthusiastic | "limited", "now open" | Clear action |

## Phase 3: Caption Structure

### Step 8: Write Hook

Load `references/hook_bank.md` for inspiration.

Hook appears in first line (visible before "...more"):
- Question hooks: "What's the #1 mistake..."
- Statement hooks: "This changed everything..."
- Story hooks: "3 months ago, Sarah couldn't..."

### Step 9: Write Body

Deliver value, story, or information:
- 2-4 sentences for single images
- Context for carousels ("swipe to see...")
- Keep paragraphs short (1-2 sentences each)

### Step 10: Write CTA

Load `references/cta_bank.md` for options.

Every post needs a clear call-to-action:
- Engagement: "Drop a [emoji] if..."
- Save: "Save this for later"
- Action: "Link in bio to..."
- Share: "Tag someone who needs this"

### Step 11: Add Hashtags

Use pre-assigned hashtags from calendar or generate:
- Instagram: 5-10 (branded + niche + local)
- Facebook: 1-3
- GBP: None

## Phase 4: Quality & Refinement

### Step 12: Voice Check

For each caption, verify:
- [ ] Matches brand tone attributes
- [ ] Uses appropriate vocabulary
- [ ] Follows emoji guidelines
- [ ] Feels authentic to client

### Step 13: Platform Optimization

**Instagram:**
- Hook in first line
- Line breaks for readability
- Hashtags at end

**Facebook:**
- Shorter is better
- Question-style hooks
- Minimal hashtags

**GBP:**
- Business-focused
- Clear contact/CTA
- No hashtags

### Step 14: Generate Variations (If Requested)

For high-priority posts, create A/B options:
- Different hook styles (question vs. statement)
- Different CTA approaches (direct vs. soft)
- Different lengths (short vs. expanded)

## Phase 5: Output

### Step 15: Format Output

Organize for easy copy/paste:

```markdown
# [CLIENT] - [MONTH] Captions

## Week 1

### Monday, [DATE]

---
**INSTAGRAM - Carousel - Educational**
Topic: [Topic]

[COMPLETE CAPTION - READY TO COPY]

Hashtags: [hashtag set]

---
**FACEBOOK - Single Image**
Topic: [Topic]

[COMPLETE CAPTION - READY TO COPY]

Hashtags: [hashtag set]
```

### Step 16: Save Output

Per-channel folder structure:
```
07_Marketing_Channels/Social_Media/Instagram/Content_Calendars/YYYY-MM_IG_Captions.md
07_Marketing_Channels/Social_Media/Facebook/Content_Calendars/YYYY-MM_FB_Captions.md
07_Marketing_Channels/Social_Media/GBP/Content_Calendars/YYYY-MM_GBP_Captions.md
```

Each file contains ready-to-copy captions organized by week and date.

## Quality Standards

Every caption must:
- Have a hook in the first line
- Match client brand voice
- Include a clear CTA
- Use appropriate platform length
- Have platform-appropriate hashtags
- Be ready to copy/paste

Every caption must avoid:
- Generic openings ("Check this out!")
- Mismatched tone
- Missing CTAs
- Wrong length for platform

## Batch Processing Tips

For full month (44+ posts):
1. Group by platform first
2. Then group by pillar
3. Write in batches (maintains voice consistency)
4. Review 2-3 captions after each batch

Time estimates:
- 44 posts: 30-45 minutes
- 12 posts (1 week): 10-15 minutes
- 4 posts (1 day): 5 minutes

## References

- `../_shared/channel_benchmarks.md` - **Research-backed engagement data, posting times, and platform specs (2024-2025)**
- `references/caption_templates.md` - Templates by pillar and format
- `references/hook_bank.md` - Opening hook examples by style
- `references/cta_bank.md` - Call-to-action options by goal
- `references/platform_specs.md` - Platform character limits and rules
