# Social Strategy: [CLIENT NAME]

## Content Pillars
1.  **[Pillar 1]** (30%)
2.  **[Pillar 2]** (25%)
3.  **[Pillar 3]** (20%)
4.  **[Pillar 4]** (15%)
5.  **[Pillar 5]** (10%)

## Posting Schedule
*   **Instagram:** [Freq]
*   **Facebook:** [Freq]
